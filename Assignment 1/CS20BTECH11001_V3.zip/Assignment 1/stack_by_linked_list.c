#include "stack_by_linked_list.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "node.h"

//Functions which will be assigned to function pointers in the struct
void pushNotInStruct(const void *stackPtr, char *elemToBePushed);
char *topNotInStruct(const void *stackPtr);
void popNotInStruct(const void *stackPtr);
bool isEmptyNotInStruct(const void *);

stack *newStack()
{
    stack *ptr = (stack *)malloc(sizeof(stack));

    ptr->numberOfElements = 0;
    ptr->head = NULL;
    ptr->tail = NULL;

    //Assigning the function pointers in struct to the externally declared global functions
    ptr->push = &pushNotInStruct;
    ptr->pop = &popNotInStruct;
    ptr->top = &topNotInStruct;
    ptr->isEmpty = &isEmptyNotInStruct;

    return ptr;
}

bool isEmptyNotInStruct(const void *stackPtr)
{
    return (((stack *)stackPtr)->numberOfElements == 0);
}

void pushNotInStruct(const void *stackPtr, char *elemToBePushed)
{
    songNode *nodeptr = newSong(elemToBePushed);
    if (((stack *)stackPtr)->numberOfElements == 0)
    {
        ((stack *)stackPtr)->head = nodeptr;
        ((stack *)stackPtr)->tail = nodeptr;
        ((stack *)stackPtr)->numberOfElements++;

        printf("%s pushed\n", ((stack *)stackPtr)->tail->songName);
    }
    else
    {
        ((stack *)stackPtr)->tail->next = nodeptr;
        nodeptr->previous = ((stack *)stackPtr)->tail;
        ((stack *)stackPtr)->tail = nodeptr;

        ((stack *)stackPtr)->numberOfElements++;
        printf("%s pushed\n", ((stack *)stackPtr)->tail->songName);
    }
}

char *topNotInStruct(const void *stackPtr)
{
    if (((stack *)stackPtr)->isEmpty(stackPtr))
    {
        printf("Error: Stack is Empty");

        /**
         * 
         * Design hole. Don't know what to return
         * 
         */
    }
    else
    {
        return (((stack *)stackPtr)->tail->songName);
    }
}

void popNotInStruct(const void *stackPtr)
{
    if (((stack *)stackPtr)->isEmpty(stackPtr))
    {
        printf("Error: The Stack is Empty\n");
    }
    else
    {
       //If stack contained only single element before pop then tail has to be assigned to NULL
        if (((stack *)stackPtr)->numberOfElements==1)
        {
            ((stack *)stackPtr)->numberOfElements--;
            ((stack *)stackPtr)->tail = NULL;
            ((stack *)stackPtr)->head = NULL;
        }
        else
        {
            songNode *tempTopPtr = ((stack *)stackPtr)->tail;
            ((stack *)stackPtr)->tail->previous->next = NULL;
            ((stack *)stackPtr)->numberOfElements--;
            ((stack *)stackPtr)->tail = tempTopPtr->previous;
        }

        //free(tempTopPtr);
    }
}