# Assignment 1 - CS2323

### Execution

Run the codes using the following command:

```
make
```

### Clean

To delete the object files and the executable, run:

```
make clean
```
