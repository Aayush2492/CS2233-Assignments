# Assignment 2- CS2323

### About `input.txt`:

<ol>
    <li>Make sure the words you want are separated(delimited) by ':' except at the end.</li>
    <li>Make sure there is no newline character or whitespace at the beginning or end.</li>
</ol>

### Execution

Run the code using the following command in the terminal:

```
make
```

Execute the executable using

```
./exec
```

### Clean

To delete the executable, run:

```
make clean
```

### Github link

The code can be found here on [github](https://github.com/Aayush2492/CS2233-Assignments/tree/master/Assignment%202)
