#ifndef I_GUARD_THE_FILE_READER_HEADER
#define I_GUARD_THE_FILE_READER_HEADER

#include "binary_search_tree.h"

void readFile(binary_search_tree*);

#endif